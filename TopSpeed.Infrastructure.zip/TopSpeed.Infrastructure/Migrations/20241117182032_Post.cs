﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TopSpeed.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Post : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Createdly",
                table: "VehicleType",
                newName: "CreatedBy");

            migrationBuilder.RenameColumn(
                name: "Createdly",
                table: "Post",
                newName: "CreatedBy");

            migrationBuilder.RenameColumn(
                name: "Createdly",
                table: "Brand",
                newName: "CreatedBy");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "CreatedBy",
                table: "VehicleType",
                newName: "Createdly");

            migrationBuilder.RenameColumn(
                name: "CreatedBy",
                table: "Post",
                newName: "Createdly");

            migrationBuilder.RenameColumn(
                name: "CreatedBy",
                table: "Brand",
                newName: "Createdly");
        }
    }
}
