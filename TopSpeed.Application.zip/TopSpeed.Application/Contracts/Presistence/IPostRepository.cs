﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TopSpeed.Application.Contracts.Persistence;
using TopSpeed.Domain.Models;

namespace TopSpeed.Application.Contracts.Presistence
{
    public interface IPostRepository: IGenericRepository<Post>
    {
        Task Update(Post post);

        Task<Post> GetPostById(Guid id);

        Task<List<Post>> GetAllPost(); 

        Task<List<Post>> GetAllPostBy(Guid? skipRecord,Guid? brandId);

        Task<List<Post>> GetAllPost(string? searchName,Guid? brandId, Guid? vehicleTypeId);
        Task<List<Post>> GetAllPost(Guid id, Guid brandId);
    }
}
