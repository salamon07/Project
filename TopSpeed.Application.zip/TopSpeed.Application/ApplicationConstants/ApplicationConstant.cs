﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TopSpeed.Application.ApplicationConstants
{
    public class ApplicationConstant
    {

    }

    public static class CommonMessage
    {
        public static string RecordCreated = "Recorded Created Successfully";
        public static string RecordUpdated = "Recorded Created Successfully";
        public static string RecordDeleted = "Recorded Created Successfully";
    }
    public static class CustomRole 
    {
        public const string MasterAdmin = "MASTERADMIN";
        public const string Admin = "ADMIN";
        public const string Customer = "CUSTOMER";

    }
}
 