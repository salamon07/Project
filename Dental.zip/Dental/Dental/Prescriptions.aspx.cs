﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Configuration;

namespace Dental
{
    public partial class Prescriptions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetPatients();
            GetTreatments();
            ShowPrescriptions();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\myb pc\Documents\DentalASPDb.mdf"";Integrated Security=True;Connect Timeout=30;Encrypt=True");


        private void ShowPatients()
        {
            Con.Open();
            string Query = "select * from PatientTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(Sda);
            var ds = new DataSet();
            Sda.Fill(ds);
            PrescriptionGV.DataSource = ds.Tables[0];
            PrescriptionGV.DataBind();
            Con.Close();
        }
        private void GetPatients()
        {
            Con.Open();
            string Query = "select * from PatientTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            DataSet ds = new DataSet();
            Sda.Fill(ds);
            PatientCb.DataTextField = ds.Tables[0].Columns["PatName"].ToString();
            PatientCb.DataValueField = ds.Tables[0].Columns["PatId"].ToString();
            PatientCb.DataSource = ds.Tables[0];
            PatientCb.DataBind();
            Con.Close();

        }
        private void GetTreatments()
        {
            Con.Open();
            string Query = "select * from TreatmentTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            DataSet ds = new DataSet();
            Sda.Fill(ds);
            TreatmentCb.DataTextField = ds.Tables[0].Columns["TreatName"].ToString();
            TreatmentCb.DataValueField = ds.Tables[0].Columns["TreatId"].ToString();
            TreatmentCb.DataSource = ds.Tables[0];
            TreatmentCb.DataBind();
            Con.Close();

        }
        private void GetCost()
        {
            Con.Open();
            string Query = "select TreatCost from TreatmentTbl where TreatId=" + TreatmentCb.SelectedValue + "";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            DataSet ds = new DataSet();
            Sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                CostTb.Value = dr["TreatCost"].ToString();
            }


            Con.Close();
        }
        protected void PatientCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void TreatmentCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetCost();
        }
        private void InsertPresc()
        {
            if (MedicineTb.Value != ""
                || QtyTb.Value != ""
                || CostTb.Value != "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Patient Inserted')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into PrescriptionTbl values(@PP,@PT,@PC,@PM,@PQ)", Con);
                    cmd.Parameters.AddWithValue("@PP", PatientCb.SelectedValue);
                    cmd.Parameters.AddWithValue("@PT", TreatmentCb.SelectedValue);
                    cmd.Parameters.AddWithValue("@PC", CostTb.Value);
                    cmd.Parameters.AddWithValue("@PM", MedicineTb.Value);
                    cmd.Parameters.AddWithValue("@PQ", QtyTb.Value);

                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Prescription Inserted')", true);
                    Con.Close();
                    ShowPrescriptions();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }
        private void EditPrescription()
        {

            if (MedicineTb.Value != ""
                || QtyTb.Value != ""
                || CostTb.Value != "")
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("Update PrescriptionTbl set Patient=@PP,Treatment=@PT,TreatCost=@PC,Medicines=@PM,MedQty=@PQ where PrescId=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PP", PatientCb.SelectedValue);
                    cmd.Parameters.AddWithValue("@PT", TreatmentCb.SelectedValue);
                    cmd.Parameters.AddWithValue("@PC", CostTb.Value);
                    cmd.Parameters.AddWithValue("@PM", MedicineTb.Value);
                    cmd.Parameters.AddWithValue("@PQ", QtyTb.Value);
                    cmd.Parameters.AddWithValue("PKey", PrescriptionGV.SelectedRow.Cells[1].Text);

                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Patient Updated!!!')", true);
                    Con.Close();
                    ShowPrescriptions();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }

        private void DeletePrescription()
        {
            if (MedicineTb.Value == "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Select Prescription!!!')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("delete PrescriptionTbl where PrescId=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PKey", PatientGV.SelectedRow.Cells[1].Text);
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Prescription Deleted')", true);
                    Con.Close();
                    ShowPrescription();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }
        void AddBtn_Click(object sender, EventArgs e)
        {
            InsertPresc();
        }

        void PaitentGV_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PatientCb.DataTextField = PrescriptionGV.SelectedRow.Cells[2].Text;
                TreatmentCb.DataTextField = PrescriptionGV.SelectedRow.Cells[3].Text;
                CostTb.Value = PrescriptionGV.SelectedRow.Cells[4].Text;
                MedicineTb.Value = PrescriptionGV.SelectedRow.Cells[5].Text;
                QtyTb.Value = PrescriptionGV.SelectedRow.Cells[6].Text;
                if (CostTb.Value == "")
                {
                    Key = 0;
                }
                else
                {
                    Key = Convert.ToInt32(PrescriptionGV.SelectedRow.Cells[1].Text);
                }
            }
            catch (Exception)
            {
                throw;
            }


        }
        void PrescEditBtn_Click(Object sender, EventArgs e)
        {
            EditPrescription();
        }
    }
}