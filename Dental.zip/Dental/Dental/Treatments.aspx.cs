﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Dental
{
    public partial class Treatments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ShowTreatments();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\myb pc\Documents\DentalASPDb.mdf"";Integrated Security=True;Connect Timeout=30;Encrypt=True");

        public object PatAllergiesTb { get; private set; }
        private void ShowTreatments()
        {
            Con.Open();
            string Query = "select * from TreatmentTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(Sda);
            var ds = new DataSet();
            Sda.Fill(ds);
            TreatmentGV.DataSource = ds.Tables[0];
            TreatmentGv.DataBind();
            Con.Close();
        }
        private void InsertTreatment()
        {
            if (TreatNameTb.Value != ""
                || TreatCostTb.Value != ""
                || TreatDesc.Value != "")
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into PatientTbl values(@TN,@TC,@TD)", Con);
                    cmd.Parameters.AddWithValue("@TN", TreatNameTb.Value);
                    cmd.Parameters.AddWithValue("@TC", TreatCostTb.Value);
                    cmd.Parameters.AddWithValue("@TD", TreatDesc.Value);
                   
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Treatment Inserted')", true);
                    Con.Close();
                    ShowPatients();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }
        private void EditTreatment()
        {
            if(TreatNameTb.Value != ""
                || TreatCostTb.Value != ""
                || TreatDesc.Value != "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Missing Data')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Update TreatmentTbl set TreatName=@TN,TreatCost=@tc", Con);
                    cmd.Parameters.AddWithValue("@TN", TreatNameTb.Value);
                    cmd.Parameters.AddWithValue("@TC", TreatCostTb.Value);
                    cmd.Parameters.AddWithValue("@TD", TreatDesc.Value);
                    cmd.Parameters.AddWithValue("@TD", TreatDesc.Value);

                    cmd.Parameters.AddWithValue("@TKey", TreatmentGV.SelectedRow.Cells[1].Text);

                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Treatment Inserted')", true);
                    Con.Close();
                    ShowTreatments();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Updated!!')", true);
                }
            }
        }
        private void DeleteTreatment()
        {
            if (TreatNameTb.Value == "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Select Treatment!!!')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("delete TreatmentTbl where TreatId=@TKey", Con);
                    cmd.Parameters.AddWithValue("@TKey", TreatmentGV.SelectedRow.Cells[1].Text);
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Treatment Deleted')", true);
                    Con.Close();
                    ShowTreatments();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Deleted!!!')", true);
                }
            } 
        }

        int Key = 0;
            
        protected void PatientGV_SelectedIndexChanged(object sender, EventArgs e)
        {
            TreatNameTb.Value = TreatmentGV.SelectedRow.Cells[2].Text;
            TreatCostTb.Value = TreatmentGV.SelectedRow.Cells[3].Text;
            TreatDesc.Value = TreatmentGV.SelectedRow.Cells[4].Text;
            
            if (TreatNameTb.Value == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(TreatmentGV.SelectedRow.Cells[1].Text);
            }
        }
        protected void AddBtn_Click(object sender, EventArgs e)
        {
            InsertTreatment();
        }
        protected void DeleteBtn_Click(object sender, EventArgs e)
        {
            DeleteTreatment();
        }
        protected void EditBtn_Click(object sender, EventArgs e)
        {
            EditTreatment();
        }

    }
}