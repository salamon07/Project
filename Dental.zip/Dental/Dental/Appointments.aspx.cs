﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Dental
{
    public partial class Appointments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetPatients();
            GetTreatments();
            ShowAppointments();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\myb pc\Documents\DentalASPDb.mdf"";Integrated Security=True;Connect Timeout=30;Encrypt=True");

        private void ShowAppointments()
        {
            Con.Open();
            string Query = "select * from AppointmentTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(Sda);
            var ds = new DataSet();
            Sda.Fill(ds);
            AppointmentGV.DataSource = ds.Tables[0];
            AppointmentGV.DataBind();
            Con.Close();
        }

        private void GetPatients()
        {
            Con.Open();
            string Query = "select * from PatientTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            DataSet ds = new DataSet();
            Sda.Fill(ds);
            PatientCb.DataTextField = ds.Tables[0].Columns["PatName"].ToString();
            PatientCb.DataValueField = ds.Tables[0].Columns["PatId"].ToString();
            PatientCb.DataSource = ds.Tables[0];
            PatientCb.DataBind();
            Con.Close();

        }
        private void GetTreatments()
        {
            Con.Open();
            string Query = "select * from TreatmentTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            DataSet ds = new DataSet();
            Sda.Fill(ds);
            TreatmentCb.DataTextField = ds.Tables[0].Columns["TreatName"].ToString();
            TreatmentCb.DataValueField = ds.Tables[0].Columns["TreatId"].ToString();
            TreatmentCb.DataSource = ds.Tables[0];
            TreatmentCb.DataBind();
            Con.Close();

        }
        int Key = 0;
        protected void PrescriptionGV_SelectedIndexChanged(object sender, EventArgs e)
        {
            PatientCb.DataTextField = AppointmentGV.SelectedRow.Cells[2].Text;
            TreatmentCb.DataTextField = AppointmentGV.SelectedRow.Cells[3].Text;
            //PatAddressTb.Value = AppointmentGV.SelectedRow.Cells[4].Text;
            Apptime.DataTextField = AppointmentGV.SelectedRow.Cells[5].Text;

            if (PatientCb.DataTextField == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(AppointmentGV.SelectedRow.Cells[1].Text);
            }
        }

        private void DeleteAppointment()
        {
            if (PatientCb.SelectedIndex == -1)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Select Prescription!!!')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("delete AppointmentTbl where AppId=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PKey", AppointmentGV.SelectedRow.Cells[1].Text);
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Appointment Deleted')", true);
                    Con.Close();
                    ShowAppointment();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Delete!!')", true);
                }
            } 
        }

            private void EditPatient()
            {
            if (AppTime.SelectedIndex == -1 || TreatmentCb.SelectedIndex == -1 || PatientCb.SelectedIndex == -1)
            {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("Update AppointmentTbl set Patient=@PN,Treatment=@PP,AppDate=@PA,ApTime=@PD where ApId = @PKey", Con);
                        cmd.Parameters.AddWithValue("@Pat", PatientCb.SelectedValue);
                        cmd.Parameters.AddWithValue("@Tr", TreatmentCb.SelectedValue);
                        cmd.Parameters.AddWithValue("@AppDate", AppDate.Value);
                        cmd.Parameters.AddWithValue("@ApTime", AppTime.SelectedValue);
                        cmd.Parameters.AddWithValue("@PKey", AppointmentGV.SelectedRow.Cells[1].Text);
                        cmd.ExecuteNonQuery();
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Patient Updated!!!')", true);
                        Con.Close();
                        ShowAppointment();
                    }
                    catch (Exception)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Updated!!!')", true);
                    }
                }
            } 
            private void InsertAppointment()
            {
                if (AppTime.SelectedIndex == -1 || TreatmentCb.SelectedIndex == -1 || PatientCb.SelectedIndex == -1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Patient Inserted')", true);
                }
                else
                {
                    try
                    {
                        Con.Open();
                        SqlCommand cmd = new SqlCommand("insert into AppointmentTbl values(@Pat,@Tr,@AppDate,@ApTime)", Con);
                        cmd.Parameters.AddWithValue("@Pat", PatientCb.SelectedValue);
                        cmd.Parameters.AddWithValue("@Tr", TreatmentCb.SelectedValue);
                        cmd.Parameters.AddWithValue("@AppDate", AppDate.Value);
                        cmd.Parameters.AddWithValue("@ApTime", AppTime.SelectedValue);

                        cmd.ExecuteNonQuery();
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Appointment Recorded')", true);
                        Con.Close();
                        ShowAppointment();
                    }
                    catch (Exception)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                    }
                }
            }
        


            protected void AddBtn_Click(object sender, EventArgs e)
            {
                InsertAppointment();
            }
            protected void DeleteBtnn_Click(object sender, EventArgs e)
            {
                DeleteAppointment();
            } 
        
    } 
    
}
        

