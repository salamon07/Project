﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.XPath;

namespace Dental
{
    public partial class Patients : System.Web.UI.Page
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\myb pc\Documents\DentalASPDb.mdf"";Integrated Security=True;Connect Timeout=30;Encrypt=True");


        private void ShowPatients()
        {
            Con.Open();
            string Query = "select * from PatientTbl";
            SqlDataAdapter Sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder Builder= new SqlCommandBuilder(Sda);
            var ds = new DataSet();
            Sda.Fill(ds);
            PatientGV.DataSource = ds.Tables[0];
            PatientGv.DataBind();
            Con.Close();
        }
        private void InsertPatient()
        {
            if (PatNameTb.Value != ""
                || PatPhoneTb.Value != ""
                || PatAddressTb.Value != ""
                || PatDOB.Value != ""
                || PatGen.Value != ""
                || PatAllergiesTb.Value != "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Patient Inserted')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("insert into PatientTbl values(@PN,@PP,@PA,@PD,@PG,@PAL)", Con);
                    cmd.Parameters.AddWithValue("@PN", PatNameTb.Value);
                    cmd.Parameters.AddWithValue("@PP", PatPhoneTb.Value);
                    cmd.Parameters.AddWithValue("@PA", PatAddressTb.Value);
                    cmd.Parameters.AddWithValue("@PD", PatDOB.Value);
                    cmd.Parameters.AddWithValue("@PG", PatGen.Value);
                    cmd.Parameters.AddWithValue("@PAL", PatAllergiesTb.Value);
                    cmd.Parameters.AddWithValue("@PKey", PatIentGv.SelectedRow.Cells[1].Text);
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Patient Inserted')", true);
                    Con.Close();
                    ShowPatients();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }
        private void EditPatient()
        {
            if (PatNameTb.Value != ""
                || PatPhoneTb.Value != ""
                || PatAddressTb.Value != ""
                || PatDOB.Value != ""
                || PatGen.Value != ""
                || PatAllergiesTb.Value != "")
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("Update PatientTbl set PatName=@PN,PatPhone=@PP,PatAdd=@PA,PatDOB=@PD,PatGen=@PG,PatAllergies=@PAL where PatId=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PN", PatNameTb.Value);
                    cmd.Parameters.AddWithValue("@PP", PatPhoneTb.Value);
                    cmd.Parameters.AddWithValue("@PA", PatAddressTb.Value);
                    cmd.Parameters.AddWithValue("@PD", PatDOB.Value);
                    cmd.Parameters.AddWithValue("@PG", PatGen.Value);
                    cmd.Parameters.AddWithValue("@PAL", PatAllergiesTb.Value);
                    cmd.Parameters.AddWithValue("@PKey", PatientGV.SelectedRow.Cells[1].Text);
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Patient Updated!!!')", true);
                    Con.Close();
                    ShowPatients();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            ShowPatients();
        }
        protected void AddBtn_Click(object sender, EventArgs e)
        {
            InsertPatient();
        }
        protected void PatientGV_SelectedIndexChanged(object sender, EventArgs e)
        {
            PatNameTb.Value = PatientGV.SelectedRow.Cells[2].Text;
            PatPhoneTb.Value = PatientGV.SelectedRow.Cells[3].Text;
            PatAddressTb.Value = PatientGV.SelectedRow.Cells[4].Text;
            PatGen.Value = PatientGV.SelectedRow.Cells[6].Text;
            PatAllergiesTb.Value = PatientGV.SelectedRow.Cells[7].Text;
            if (PatNameTb.Value == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(PatientGV.SelectedRow.Cells[1].Text);
            } 
        }
        protected void EditBtnn_Click(object sender, EventArgs e)
        {
                EditPatient();
        }
        private void DeletePatient()
        {
            if (PatNameTb.Value=="")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "alert('Select Patient!!!')", true);
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("delete PatientTbl where PatId=@PKey", Con);
                    cmd.Parameters.AddWithValue("@PKey", PatientGV.SelectedRow.Cells[1].Text);
                    cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Patient Deleted')", true);
                    Con.Close();
                    ShowPatients();
                }
                catch (Exception)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Not Inserted!!')", true);
                }
            }
        }

        protected void DeleteBtnn_Click(Object sender, EventArgs e)
        {
            DeletePatient();
        }    
    }
}